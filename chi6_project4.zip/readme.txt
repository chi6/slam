1. Run main.py , change the name of the file path, then you can run the slam.
Note: the time step is set to dt = 2, you can change it  to make the plot faster.

2. When you finish the slam, the result will be saved. Then run test_MapUtils.py, you can see the result of the slam map.

3. for texture map, run texture_map.py, change the name of file name, then you can see the texture map. Note: for different data, you need to set different threshhold for showing the map.

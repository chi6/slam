import load_data as ld
import p4_util as util
from MapUtils import*
from matplotlib import pyplot as plt
import pickle




#load data
joint = ld.get_joint("./Proj4_2018_test/test_joint")
lidar = ld.get_lidar("./Proj4_2018_test/test_lidar")


lidar['rpy'][:, 2] = lidar['rpy'][:, 2] - lidar['rpy'][0, 2]

head_angles = joint['head_angles']
scan = np.array(lidar['scan']).squeeze()
angles = np.array([np.arange(-135,135.25,0.25)*np.pi/180.]).squeeze()
position = np.array(lidar['pos']).squeeze()



# init MAP
MAP = {}
MAP['res']   = 0.05 #meters
MAP['xmin']  = -20  #meters
MAP['ymin']  = -20
MAP['xmax']  =  20
MAP['ymax']  =  20
MAP['sizex']  = int(np.ceil((MAP['xmax'] - MAP['xmin']) / MAP['res'] + 1)) #cells
MAP['sizey']  = int(np.ceil((MAP['ymax'] - MAP['ymin']) / MAP['res'] + 1))
MAP['occ'] = 3
MAP['free'] = -1
MAP['odds'] = np.zeros((MAP['sizex'],MAP['sizey']))
MAP['map'] = np.zeros((MAP['sizex'],MAP['sizey']),dtype=np.int8) #DATA TYPE: char or int8

# init particles
particle_num = 100
particle_pos = np.zeros((particle_num, 3))
particle_weight = np.ones((particle_num, 1))/particle_num
N_eff_threshold = 10
best_pos = particle_pos[0,0:3]
path = []


dt = 2
for count in range(0,scan.shape[0],dt):

    #best_pos = position[count][0:3]
    print("iter: {}".format(count))

    # take valid indices
    indValid = np.logical_and((scan[count] < 30),(scan[count]> 0.1))
    scan_data = scan[count][indValid]
    angle = angles[indValid]
    # xy position in the sensor frame
    xs0 = np.array([scan_data * np.cos(angle)])
    ys0 = np.array([scan_data * np.sin(angle)])
    n = xs0.shape[1]

    # sync time step
    index = (np.abs(lidar['t'][count] - joint['ts'][0])).argmin()
    # transform the lidar scan from robot frame to world frame
    neck_angle = head_angles[0, index]
    head_angle = head_angles[1, index]
    # Center of Mass kept at 0.93 meters
    # Head: 33.0cm above Center of Mass
    # IMU: 16.0cm below Center of Mass
    # Lidar: 15.0cm above head
    # Kinect​ : 7.0cm above Head
    x = best_pos[0]
    y = best_pos[1]
    z = 0.93 - 0.16
    T1 = np.array([[1, 0, 0, x],
                    [0, 1, 0, y],
                    [0, 0, 1, z],
                    [0, 0, 0, 1]])
    yaw = best_pos[2]
    pitch = lidar['rpy'][count,1]
    row = lidar['rpy'][count,0]
    Tz = np.array([[np.cos(yaw), -np.sin(yaw), 0, 0],
                       [np.sin(yaw), np.cos(yaw), 0, 0],
                       [0, 0, 1, 0],
                       [0, 0, 0, 1]])
    Tz1 = np.array([[np.cos(pitch), 0,-np.sin(pitch), 0],
                       [0,1, 0, 0],
                       [np.sin(pitch), 0,np.cos(pitch), 0],
                       [0, 0, 0, 1]])
    Tz2 = np.array([[1,0,0, 0],
                       [0,np.cos(row), -np.sin(row), 0],
                       [0,np.sin(row), np.cos(row), 0],
                       [0, 0, 0, 1]])
    Tz3 =  np.array([[1, 0, 0, 0],
                    [0, 1, 0, 0],
                    [0, 0, 1, 0.16+0.33],
                    [0, 0, 0, 1]])
    Ty = np.array([[np.cos(neck_angle), -np.sin(neck_angle), 0, 0],
                       [np.sin(neck_angle), np.cos(neck_angle), 0, 0],
                       [0, 0, 1, 0],
                       [0, 0, 0, 1]])
    Ty1 = np.array([[np.cos(head_angle), 0, np.sin(head_angle), 0],
                       [0, 1, 0, 0],
                       [-np.sin(head_angle), 0, np.cos(head_angle), 0],
                       [0, 0, 0, 1]])
    T2 = np.array([[1,0, 0, 0],
                    [0,1, 0, 0],
                    [0, 0, 1, 0.15],
                    [0, 0, 0, 1]])

    T = T1.dot(Tz).dot(Tz1).dot(Tz2).dot(Tz3).dot(Ty).dot(Ty1).dot(T2)

    pos_xy = np.vstack((xs0,ys0))
    pos_xy = np.vstack((pos_xy,np.zeros([1,n])))
    pos_lidar = np.vstack((pos_xy, np.ones([1,n])))


    pos_world = T.dot(pos_lidar)
    above_floor = (pos_world[2] > 0.00)
    pos_world = pos_world[:, above_floor]
    # discretize to map cell drop out the point outside map
    discrete_x = np.ceil((pos_world[0,:] - MAP['xmin']) / MAP['res'] + 1).astype(np.int64)
    discrete_y = np.ceil((pos_world[1,:] - MAP['ymin']) / MAP['res'] + 1).astype(np.int64)
    discrete_x[discrete_x >= MAP['sizex']] = MAP['sizex'] - 1
    discrete_y[discrete_y >= MAP['sizey']] = MAP['sizey'] - 1

    best_x = np.ceil((best_pos[0] - MAP['xmin']) / MAP['res'] + 1).astype(np.int64)
    best_y = np.ceil((best_pos[1] - MAP['ymin']) / MAP['res'] + 1).astype(np.int64)

    xyio = getMapCellsFromRay(best_x, best_y, discrete_x, discrete_y)
    free_x = xyio[0,:].astype(np.int64)
    free_y = xyio[1,:].astype(np.int64)
    free_x[free_x >= MAP['sizex']] = MAP['sizex'] - 1
    free_y[free_y >= MAP['sizey']] = MAP['sizey'] - 1
    # update log odds
    MAP['odds'][discrete_x,discrete_y] += MAP['occ']
    MAP['odds'][free_x, free_y] += MAP['free']
    MAP['odds'][np.logical_or(MAP['odds'] > 120*MAP['occ'], MAP['odds']<-120*MAP['occ'])] = 0
    MAP['map'] = (MAP['odds'] > 0).astype(np.int8)

    path.append(best_pos)
    if count%30 ==0 :
        # plot point
        print('iter: ', count, 'pos: ', best_x, ',', best_y, 'log odds: ', np.sum(np.sum(MAP['map'])))
        plt.plot(best_y, best_x, '*')

        # plot map
        plt.imshow(MAP['odds'], cmap= 'magma')

    plt.pause(0.001)
    '''
    then doing MCL
    '''
    if count >= 1:
        # compute local odometry
        particle_pos = compute_local_odometry(particle_pos, position[count,:2], position[count-dt,:2],
                                              lidar['rpy'][count, 2],lidar['rpy'][count-dt,2],particle_num,neck_angle)

        # transform the coordinate to world frame
        particle_map = transform_particle_to_world_frame(pos_xy, neck_angle, head_angle, particle_pos)

        # compute map correlation
        corr_socre = mapCorrelation(particle_map, MAP)

        # update weights
        log_weights = np.log(particle_weight) + corr_socre[:,np.newaxis]
        log_weights_el = log_weights - np.max(log_weights)
        Norm = np.log(np.sum(np.exp(log_weights_el)))
        log_weights = log_weights_el - Norm
        particle_weight = np.exp(log_weights)

        # best correlation
        best_ind = np.argmax(particle_weight)
        best_pos = particle_pos[best_ind]

        # resampling
        N_eff = 1/np.sum(particle_weight**2)
        print(N_eff)

        if N_eff < N_eff_threshold:
            print('resample')
            particle_pos, particle_weight = resample(particle_pos,particle_weight)


np.save("path_test",path)
np.save("map_test", MAP['odds'])

t = 0
while True:
    plt.imshow(MAP['odds'], cmap= 'magma')
    plt.pause(0.1)

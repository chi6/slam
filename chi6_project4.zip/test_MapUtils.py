import numpy as np
import matplotlib.pyplot as plt
from scipy import io
import matplotlib.image as mpimg
import MapUtils as MU
from mpl_toolkits.mplot3d import Axes3D
import time

path0 = np.load("path_test.npy")
map0 = np.load("map_test.npy")
MAP = {}
MAP['res']   = 0.05 #meters
MAP['xmin']  = -20  #meters
MAP['ymin']  = -20
t = 0
best_x = np.ceil((path0[:,0] - MAP['xmin']) / MAP['res'] + 1).astype(np.int64)
best_y = np.ceil((path0[:,1] - MAP['ymin']) / MAP['res'] + 1).astype(np.int64)
#map0[map0<-0] = -1

#map0[map0>0] = 1
while True:
	plt.plot(best_y, best_x,'.')
	plt.imshow(map0,cmap='magma')
	t += 2
	plt.pause(0.01)
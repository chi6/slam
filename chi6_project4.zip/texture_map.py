import load_data as ld
import p4_util as util
from MapUtils import*
from matplotlib import pyplot as plt
import pickle

#load data
joint = ld.get_joint("./Proj4_2018_Train/data/train_joint3")
lidar = ld.get_lidar("./Proj4_2018_Train/data/train_lidar3")
depth = ld.get_depth("./Proj4_2018_Train_rgb/DEPTH_3")
rgb = ld.get_rgb("./Proj4_2018_Train_rgb/RGB_3_3")

path = np.load("path3.npy")
map_res = np.load("map3.npy")

# Load kinect parameters
fex = open('./Proj4_2018_Train_rgb/cameraParam/exParams.pkl', 'rb')
fIR = open('./Proj4_2018_Train_rgb/cameraParam/IRcam_Calib_result.pkl', 'rb')
fRGB = open('./Proj4_2018_Train_rgb/cameraParam/RGBcamera_Calib_result.pkl', 'rb')
exParams = pickle.load(fex,encoding='bytes')
irParams = pickle.load(fIR,encoding='bytes')
rgbParams = pickle.load(fRGB,encoding='bytes')


# init MAP
MAP = {}
MAP['res']   = 0.05 #meters
MAP['xmin']  = -20  #meters
MAP['ymin']  = -20
MAP['xmax']  =  20
MAP['ymax']  =  20
MAP['sizex']  = int(np.ceil((MAP['xmax'] - MAP['xmin']) / MAP['res'] + 1)) #cells
MAP['sizey']  = int(np.ceil((MAP['ymax'] - MAP['ymin']) / MAP['res'] + 1))

# construct camera matrix
#pdb.set_trace()
KIR = np.array([[irParams[b'fc'][0], irParams[b'alpha_c'], irParams[b'cc'][0], 0.0], [0.0, irParams[b'fc'][1], irParams[b'cc'][1], 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]])
Kinv = np.linalg.inv(KIR)
KC = np.array([[rgbParams[b'fc'][0], rgbParams[b'alpha_c'], rgbParams[b'cc'][0], 0.0], [0.0, rgbParams[b'fc'][1], rgbParams[b'cc'][1], 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]])


head_angles = joint['head_angles']
MAP['color_map'] = np.zeros((MAP['sizex'],MAP['sizey'],3),dtype=np.uint8)

ground_threshhold = 0.1
dt = 2 # map0 : 20, map1 : 10, map2 : 20
index_t = 0
for count in range(0, len(rgb['t'])):
    print('iter:', count,'t:',index_t)
    # sync time step
    # transform depth and image
    index= np.abs(lidar['t'] - rgb['t'][count]).argmin()
    index_t = (index/dt).astype(np.int64)
    index_joint = (np.abs(lidar['t'][index] - joint['ts'][0])).argmin()
    # transform the lidar scan from robot frame to world frame
    neck_angle = head_angles[0, index_joint]
    head_angle = head_angles[1, index_joint]

    # get IR image
    depth_map = depth[count]['depth']*0.001
    u,v = np.meshgrid(np.arange(depth_map.shape[0]), np.arange(depth_map.shape[1]).T)
    u_v = np.vstack((u.flatten()[np.newaxis, :],v.flatten()[np.newaxis, :]))
    u_v = np.vstack((u_v*depth_map.flatten(), depth_map.flatten()))
    u_v = np.vstack((u_v, np.ones([1,u_v.shape[1]])))
    #x_IR = 0.001*u.flatten()[np.newaxis, :]*depth_map.flatten()/irParams[b'fc'][0]+irParams[b'cc'][0]
    #y_IR = 0.001*v.flatten()[np.newaxis, :]*depth_map.flatten()/irParams[b'fc'][1]+irParams[b'cc'][1]
    #u_v = np.vstack((x_IR,y_IR))
    #x_y_IR = np.vstack((u_v, depth_map.flatten()))
    x_y_IR = Kinv.dot(u_v)
    x_y_z_IR = x_y_IR
    #x_y_z_IR = np.vstack((x_y_IR[0:3]*depth_map.flatten()))

    x_y_z_RGB = exParams[b'R'].dot(x_y_z_IR[0:3])+exParams[b'T']*0.001
    x_y_z_RGB = np.vstack((x_y_z_RGB,np.ones([1,u_v.shape[1]])))

    u_v_rgb = KC.dot(x_y_z_RGB)
    discrete_u = (np.ceil(u_v_rgb[0]/u_v_rgb[2])+1).astype(np.int64)
    discrete_u[discrete_u<0] = 0
    discrete_u[discrete_u>MAP['sizex']] = MAP['sizex']-1
    discrete_v = (np.ceil(u_v_rgb[1]/u_v_rgb[2])+1).astype(np.int64)
    discrete_v[discrete_v<0] = 0
    discrete_v[discrete_v>MAP['sizey']] = MAP['sizey']-1

    # get best_pos
    best_pos = path[index_t]
    x = best_pos[0]
    y = best_pos[1]
    z = 0.93 - 0.16
    T1 = np.array([[1, 0, 0, x],
                    [0, 1, 0, y],
                    [0, 0, 1, z],
                    [0, 0, 0, 1]])
    yaw = best_pos[2]
    pitch = lidar['rpy'][count,1]
    row = lidar['rpy'][count,0]
    Tz = np.array([[np.cos(yaw), -np.sin(yaw), 0, 0],
                       [np.sin(yaw), np.cos(yaw), 0, 0],
                       [0, 0, 1, 0],
                       [0, 0, 0, 1]])
    Tz1 = np.array([[np.cos(pitch), 0,-np.sin(pitch), 0],
                       [0,1, 0, 0],
                       [np.sin(pitch), 0,np.cos(pitch), 0],
                       [0, 0, 0, 1]])
    Tz2 = np.array([[1,0,0, 0],
                       [0,np.cos(row), -np.sin(row), 0],
                       [0,np.sin(row), np.cos(row), 0],
                       [0, 0, 0, 1]])
    Tz3 =  np.array([[1, 0, 0, 0],
                    [0, 1, 0, 0],
                    [0, 0, 1, 0.16+0.33],
                    [0, 0, 0, 1]])
    Ty = np.array([[np.cos(neck_angle), -np.sin(neck_angle), 0, 0],
                       [np.sin(neck_angle), np.cos(neck_angle), 0, 0],
                       [0, 0, 1, 0],
                       [0, 0, 0, 1]])
    Ty1 = np.array([[np.cos(head_angle), 0, np.sin(head_angle), 0],
                       [0, 1, 0, 0],
                       [-np.sin(head_angle), 0, np.cos(head_angle), 0],
                       [0, 0, 0, 1]])
    T2 = np.array([[1,0, 0, 0],
                    [0,1, 0, 0],
                    [0, 0, 1, 0.7],
                    [0, 0, 0, 1]])
    R = np.array([[0,0, 1, 0],
                  [0,-1, 0, 0],
                  [1, 0, 0, 0],
                    [0, 0, 0, 1]])
    T = T1.dot(Tz).dot(Tz1).dot(Tz2).dot(Tz3).dot(Ty).dot(Ty1).dot(T2).dot(R)


    para_ground = T.dot(x_y_z_RGB)#np.vstack((x_y_z_IR,np.ones([1,u_v.shape[1]]))))#
    ind_upgound = para_ground[2,:] < 0.2
    print(np.sum(ind_upgound.astype(np.int64)))

    para_ground = para_ground[:,ind_upgound]
    discrete_u = discrete_u[ind_upgound]
    discrete_v = discrete_v[ind_upgound]

    discrete_x = np.ceil((para_ground[0,:] - MAP['xmin']) / MAP['res'] + 1).astype(np.int64)
    discrete_y = np.ceil((para_ground[1,:] - MAP['ymin']) / MAP['res'] + 1).astype(np.int64)
    discrete_x[discrete_x<0] = 0
    discrete_y[discrete_y<0] = 0
    discrete_x[discrete_x>=MAP['sizex']] = MAP['sizex']-1
    discrete_y[discrete_y>=MAP['sizey']] = MAP['sizey']-1

    MAP['color_map'][discrete_x, discrete_y,:] = rgb['img'][count][discrete_u,discrete_v]

MAP['color_map'][map_res>-0.2] = 0
plt.imshow(MAP['color_map'])
#plt.imshow(map_res)
plt.show()
#Daniel D. Lee, Alex Kushleyev, Kelsey Saulnier, Nikolay Atanasov
import numpy as np

# INPUT 
# im              the map 
# x_im,y_im       physical x,y positions of the grid map cells
# vp(0:2,:)       occupied x,y positions from range sensor (in physical unit)  
# xs,ys           physical x,y,positions you want to evaluate "correlation" 
#
# OUTPUT 
# c               sum of the cell values of all the positions hit by range sensor
def mapCorrelation(particle_map, MAP):
    discrete_x = np.ceil((particle_map[:, 0, :] - MAP['xmin']) / MAP['res'] + 1).astype(np.int64)
    discrete_y = np.ceil((particle_map[:, 1, :] - MAP['ymin']) / MAP['res'] + 1).astype(np.int64)
    discrete_x[discrete_x >= MAP['sizex']] = MAP['sizex'] - 1
    discrete_y[discrete_y >= MAP['sizey']] = MAP['sizey'] - 1

    # correlation
    corr_score = np.sum(MAP['map'][discrete_x,discrete_y], axis=1)

    return corr_score

def find_rgb_from_data(map, rgb_map,IR_data, fc,cc, rot, t):

    u = IR_data[0,:]
    v = IR_data[1,:]
    d = IR_data[2,:]
    z = 1/d

    fu = fc[0]
    fv = fc[1]

    x_IR = u*z/fu
    y_IR = v*z/fv
    X_IR = np.vstack((x_IR,y_IR))

    X_rgb = rot.dot(X_IR) + t

    u_rgb = X_rgb[0,:]/X_rgb[2,:]*cc[0]
    v_rgb = X_rgb[1,:]/X_rgb[2,:]*cc[1]

    map[u,v] = rgb_map[u_rgb,v_rgb]

#Bresenham's line algorithm
def getMapCellsFromRay(x0t,y0t,xis,yis):
    nPoints = np.size(xis)
    xyio = np.array([[],[]])
    for x1, y1 in zip(xis,yis):
          ox,oy = bresenham2D(x0t,y0t,x1,y1)
          xyio = np.concatenate((xyio,np.array([ox,oy])),axis=1)
    return xyio

# Bresenham's ray tracing algorithm in 2D.
# Inputs:
#	(sx, sy)	start point of ray
#	(ex, ey)	end point of ray
def bresenham2D(sx, sy, ex, ey):
  sx = int(round(sx))
  sy = int(round(sy))
  ex = int(round(ex))
  ey = int(round(ey))
  dx = abs(ex-sx)
  dy = abs(ey-sy)
  steep = abs(dy)>abs(dx)
  if steep:
    dx,dy = dy,dx # swap

  if dy == 0:
    q = np.zeros((dx+1,1))
  else:
    q = np.append(0,np.greater_equal(np.diff(np.mod(np.arange( np.floor(dx/2), -dy*dx+np.floor(dx/2)-1,-dy),dx)),0))
  if steep:
    if sy <= ey:
      y = np.arange(sy,ey+1)
    else:
      y = np.arange(sy,ey-1,-1)
    if sx <= ex:
      x = sx + np.cumsum(q)
    else:
      x = sx - np.cumsum(q)
  else:
    if sx <= ex:
      x = np.arange(sx,ex+1)
    else:
      x = np.arange(sx,ex-1,-1)
    if sy <= ey:
      y = sy + np.cumsum(q)
    else:
      y = sy - np.cumsum(q)
  return np.vstack((x,y))

def compute_local_odometry(particle_pos, pose_cur, pose_post, yaw_cur, yaw_post,particle_num,neck_angle):

    noise = np.random.multivariate_normal(mean=np.zeros(3),
        cov= np.array([[0.001, 0, 0],
                      [0, 0.001, 0],
                      [0, 0, 0.5*np.pi/180/100]]),
        size=particle_num)
    # global odometry
    delta_pos_g = pose_cur - pose_post
    delta_theta_g = yaw_cur - yaw_post

    # transform to local frame
    R_world2local = np.array([[np.cos(yaw_post), -np.sin(yaw_post)],
                             [np.sin(yaw_post), np.cos(yaw_post)]]).T
    delta_pos_l = R_world2local.dot(delta_pos_g[0:2])

    # motion update
    theta = particle_pos[:,2]
    R_theta = np.array([[np.cos(theta), -np.sin(theta)],
                       [np.sin(theta), np.cos(theta)]])
    d_pos = R_theta.transpose([2,0,1]).dot(delta_pos_l)
    d_theta = delta_theta_g

    # propagate particles
    particle_pos[:, :2] += d_pos[:, :2] + noise[:, :2]
    particle_pos[:, 2] += d_theta + noise[:, 2]

    return particle_pos

def transform_particle_to_world_frame(pos_xy, neck_angle, head_angle, particle_pos):
    n = particle_pos.shape[0]
    particle_num = pos_xy.shape[1]
    res = []
    for i in range(n):
        x = particle_pos[i,0]
        y = particle_pos[i,1]
        z = 0.93 + 0.33
        T1 = np.array([[1, 0, 0, x],
                       [0, 1, 0, y],
                       [0, 0, 1, z],
                       [0, 0, 0, 1]])
        yaw = particle_pos[i,2] + neck_angle
        Tz = np.array([[np.cos(yaw), -np.sin(yaw), 0, 0],
                       [np.sin(yaw), np.cos(yaw), 0, 0],
                       [0, 0, 1, 0],
                       [0, 0, 0, 1]])
        Ty = np.array([[np.cos(head_angle), 0, np.sin(head_angle), 0],
                       [0, 1, 0, 0],
                       [-np.sin(head_angle), 0, np.cos(head_angle), 0],
                       [0, 0, 0, 1]])
        T2 = np.array([[1, 0, 0, 0],
                       [0, 1, 0, 0],
                       [0, 0, 1, 0.15],
                       [0, 0, 0, 1]])
        T = T1.dot(Tz).dot(Ty).dot(T2)

        xy = np.vstack((pos_xy[0:2, :], np.zeros([1, particle_num])))
        pos_lidar = np.vstack((xy, np.ones([1, particle_num])))

        pos_world = T.dot(pos_lidar)
        above_floor = (pos_world[2] > 0.00)
        pos_world = pos_world[:, above_floor]
        res.append(pos_world)

    return np.array(res)

def resample(particle_pos, particle_weight):
    n = particle_pos.shape[0]
    random_weights = np.random.uniform(0, 1/n)
    c = particle_weight[0]
    i = 0
    new_particle = []
    for k in range(1, n+1):
        accumulate = random_weights + (k-1)/n
        while accumulate > c:
            i+=1
            c += particle_weight[i]
        new_particle.append(particle_pos[i])
    particle_pos = np.array(new_particle)
    particle_weight = np.ones((n, 1))/n

    return particle_pos, particle_weight